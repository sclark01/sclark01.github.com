scorecenter

1. I believe all aspects of the work have been correctly implemented
2. I got some advice from Connor Taylor and Spencer Meldrum 
3. Spent probably 6 hours in total
