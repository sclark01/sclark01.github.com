var express = require ("express");
var app = express();
	app.use(express.bodyParser());
	app.set('title', 'ScoreCenter');

var mongoUri = process.env.MONGOLAB_URI || 
  process.env.MONGOHQ_URL || 
  'mongodb://sclark01:tyefifi21@dharma.mongohq.com:10019/highscores';
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
	if(error){
		console.log("Experiencing Problems");
	}
	db = databaseConnection;
});

app.all('/', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  next();
 });

app.get('/', function (request, response, next) {
	response.set('Content-Type', 'text/html');
	var index = "";
	db.collection("highscores", function(error, collection){
		if(error){
			response.send("Sorry, try again later, something went wrong");
		}
		collection.find().sort({"created_at": -1}).toArray(function(error, documents){
			if(error){
				response.send("Sorry, try again later, something went wrong");
			}
			index += '<!DOCTYPE HTML><html><head><title>Score Center</title></head><body><h1>Score Center</h1><table border="1"><tr><th>Game</th><th>User Name</th><th>Score</						th><th>Date Played</th></tr>';
			for (i = 0; i < documents.length; i++){
				index += "<td>" + documents[i].game_title + "</td>" + "<td>" + documents[i].username + "</td><td>" + documents[i].score + "</td><td>" + 			documents[i].created_at + "</tr>";
			}
			index += "</table></body></html>";
			response.send(index);
		});
	});
});

app.post('/submit.json', function(request, response, next){
	var title = request.body.game_title;
	var username = request.body.username;
	var score = parseInt(request.body.score);
	var date = Date();
	
	db.collection("highscores", function(error, collection){
		if(error){
				res.send("Oh No! Unable to save data");
			}
		collection.insert({"game_title": title, "username": username, "score": score, "created_at": date}, function(error, saved){
			if(error){
				res.send("Oh No! Unable to save data");
			}
		});
	});
	response.set("Content-Type", 'text/hmtl');
	response.send("Success");
});

app.get('/highscores.json', function(request, response, next) {
	var title = request.query["game_title"];
	db.collection("highscores", function(error, collection){
		if(error){
				response.send("Sorry, try again later, something went wrong");
		}
		collection.find({"game_title": title}).sort({"score": -1}).limit(10).toArray(function(error, documents){
			if(error){
				response.send("Sorry, try again later, something went wrong");
			}
			response.send(documents);
		});
	});
});


app.get('/usersearch', function(request, response, next) {
	response.set('Content-Type', 'text/html');
	response.send('<!DOCTYPE HTML><html><head><title>User Search</title></head><body><form name="Find User" action="" method="post"><input type="text" name="username" id = "input"><input type="submit" value="Submit" id = "submit"></form></body></html>');
});


app.post('/usersearch', function(request, response, next) {
	var index = "";
	var username = request.param('username');	
	response.set('Content-Type', 'text/html');
	db.collection("highscores", function(error, collection){
		if(error){
				response.send("Sorry, try again later, something went wrong");
			}
		collection.find({"username": username}).sort({"score": -1}).toArray(function(error, documents){
			if(error){
				response.send("Sorry, try again later, something went wrong");
			}
			index += '<!DOCTYPE HTML><html><head><title>'+ username + '</title></head><body><h1>High Scores for ' + username + '</h1><table border="1"><tr><th>Game</								th><th>Score</th><th>Date Played</th></tr>';
			for (i = 0; i < documents.length; i++){
				index += "<td>" + documents[i].game_title + "</td>" + "<td>" + documents[i].score + "</td><td>" + documents[i].created_at + "</td></tr>";
			}
			index += "</table></body></html>";
			response.send(index);

		});
	});
});

app.listen(process.env.PORT || 3000);

